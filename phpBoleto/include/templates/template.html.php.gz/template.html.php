<font size="2" face="%HTMLFONT%"><b>Instru��es para impress�o: </b>
<p>
<ul>
  <script language="JavaScript">
  <!--
  var app=navigator.appName;
  if(app.indexOf('Netscape') != -1) {      
      document.write("<li>Utilize os <font color='#FF0000'>Fontes definidos no ");
      document.write("documento em tamanho 12</font> (no menu Editar, selecionar Prefer�ncias, em seguida ");
      document.write("selecionar Fontes, definir o tamanho do Fonte Largura Vari�vel como 12 e selecionar Usar ");
      document.write("Fontes do Documento...).</li>");                
  } else if(app.indexOf('Microsoft') != -1) { 
      document.write("<li><font SIZE='2' face='%HTMLFONT%'>Utilize </font>");
      document.write("<font face='%HTMLFONT%' size='1'><font color='#FF0000'>Fontes de tamanho m�dio</font> ");
      document.write("(no menu Exibir, selecionar Fontes, M�dio).</li>");
  }
  //-->
  </script>
  <li>Imprimir em impressora jato de tinta ou laser em <font color="#FF0000">qualidade
  normal</font>. (n�o utilize qualidade rascunho).</li>
  <li>Corte nas linhas indicadas.&nbsp; </font><font size="2" face="%HTMLFONT%"></li>
</ul>

<font size="2" face="%HTMLFONT%"><b>Instru��es de pagamento: </b>
<ul>
  <li>Caso voce n�o queira imprimir o boleto banc�rio, ou prefira pagar pelo Home Banking, utilize as seguintes informa��es:<p></li>
  <li>linha digitada: <b>%LINHA%</b></li> 
  <li>valor: <b>R$ %VDOC%</b></li> 
</ul>
</font>
</p>
<p>
<table width="640" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="320">&nbsp;</td>   
    <td align="RIGHT" valign="BOTTOM" width="320">
      <font face="%HTMLFONT%" SIZE="2"><b>RECIBO DO SACADO</b></font>
    </td>
  </tr>
</table>
<table width="640" border="01" cellspacing="0" cellpadding="02">
  <tr>
    <td width="250" align="left"><font face="Arial" size="1">Cedente: <br>
    </font><font size="2" face="Arial"><b>%CDTE%</b></font><br>
    </td>
    <td width="160" align="left"><p align="center"><font face="%HTMLFONT%" SIZE="1">Ag�ncia/Cod.
    Cedente <br>
    </font><font size="2" face="%HTMLFONT%"><b>%AGCOD%</b></font><br>
    </td>
    <td width="115" align="left"><p align="center"><font face="%HTMLFONT%" SIZE="1">Data do
    Documento<br>
    </font><font face="%HTMLFONT%" size="2"><b>%DDOC%</b></font><br>
    </td>
    <td width="115" align="right"><p align="center"><font face="%HTMLFONT%" SIZE="1">Vencimento <br>
    </font><font size="3" face="%HTMLFONT%"><b>%VCTO%</b></font><br>
    </td>
  </tr>
</table>
<table width="640" border="01" cellspacing="0" cellpadding="02">
  <tr align="left">
    <td width="250" align="left"><font face="%HTMLFONT%" SIZE="1">Sacado <br>
    </font><font face="%HTMLFONT%" size="2"><b>%SACADO%</b></font><br>
    </td>
    <td width="160" align="left"><font face="%HTMLFONT%" SIZE="1"> N�mero Documento<br>
    </font><font face="%HTMLFONT%" SIZE="2"><b>%NDOC%</b></font><br>
    </td>
    <td width="115" align="left"><font face="%HTMLFONT%" SIZE="1"> Nosso N�mero<br>
    </font><font face="%HTMLFONT%" SIZE="2"><b>%NNUM%</b></font><br>
    </td>
    <td width="115" align="right"><font face="%HTMLFONT%" SIZE="1">Valor do Documento <br>
    </font><font face="%HTMLFONT%" size="3"><b>%VDOC%</b></font><br>
    </td>
  </tr>
</table>
<table width="640" border="01" cellspacing="0" cellpadding="02">
  <tr>
    <td width="100%" align="left"><font face="%HTMLFONT%" SIZE="1">Demonstrativo: <br>
    </font><font face="%HTMLFONT%" SIZE="2"><b>%DEMONS1%<br>
    %DEMONS2%<br>
    %DEMONS3%<br>
    %DEMONS4%</b></font></td>
  </tr>
</table>
<table width="640" border="00" cellspacing="0" cellpadding="02">
  <tr>
    <td width="100%" align="right"><b><font face="%HTMLFONT%" SIZE="2">Autentica��o mec�nica </font></b><br>
    </td>
  </tr>
  <tr>
    <td width="100%" align="center">&nbsp;</td>
  </tr>
</table>
<table width="640" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><div align="left"><b><i>Corte na linha abaixo</i></b></div><hr width=640></td>
  </tr>
</table>
<table width="640" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="155"><p align="center"><big><strong>%BANK%</strong></big></td>
    <td width="69" style="border-left: thin solid; border-right: thin solid"><p align="center"><big><big><strong>%BANKCODE%</strong></big></big></td>
    <td align="RIGHT" valign="BOTTOM" width="433" nowrap><font size="3" face="%HTMLFONT%"><tt><b>%LINHA%</b> </tt></font></td>
  </tr>
</table>
<table width="640" border="1" cellspacing="0" cellpadding="01">
  <tr>
    <td colspan="6"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top" width="120"><font face="%HTMLFONT%" SIZE="1">Local de Pagamento: </font><br>
        </td>
        <td valign="top" width="370"><font size="2" face="%HTMLFONT%"><b>%LP%</b></font><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="150"><table border="0" cellspacing="0" cellpadding="0" height="100%"
    width="100%" border="01">
      <tr>
        <td><font face="Arial" size="1">Vencimento </font><br>
        </td>
      </tr>
      <tr>
        <td align="RIGHT"><b><font face="Arial" size="3">%VCTO%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td colspan="6" width="487" valign="top"><table width="100%" border="0" cellspacing="0"
    cellpadding="0">
      <tr>
        <td valign="top"><font face="%HTMLFONT%" SIZE="1">Cedente </font><br>
        </td>
      </tr>
      <tr>
        <td valign="top"><b><font face="%HTMLFONT%" SIZE="2">%CDTE%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td><table width="100%" border="0" cellspacing="1" cellpadding="1">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Ag�ncia/C�digo Cedente </font><br>
        </td>
      </tr>
      <tr>
        <td align="RIGHT"><b><font face="%HTMLFONT%" SIZE="1">%AGCOD%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td width="130"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Data do documento: </font><br>
        </td>
      </tr>
      <tr>
        <td align="CENTER"><b><font face="%HTMLFONT%" SIZE="1">%DDOC%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="120" colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">No. do documento </font><br>
        </td>
      </tr>
      <tr>
        <td align="CENTER">%NDOC%<br>
        </td>
      </tr>
    </table>
    </td>
    <td width="80"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Esp�cie doc. </font><br>
        </td>
      </tr>
      <tr>
        <td align="CENTER"><font face="%HTMLFONT%" size="1"><b>%EDOC%</b></font><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="40"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Aceite </font><br>
        </td>
      </tr>
      <tr>
        <td align="CENTER"><b><font face="%HTMLFONT%" SIZE="1">%ACT% </font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="120"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Data Processamento </font></td>
      </tr>
      <tr>
        <td align="CENTER"><b><font face="%HTMLFONT%" SIZE="1">%DPROC%</font></b></td>
      </tr>
    </table>
    </td>
    <td width="140"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Nosso N�mero </font><br>
        </td>
      </tr>
      <tr>
        <td align="RIGHT"><b><font face="%HTMLFONT%" SIZE="1">%NNUM%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td width="129"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Uso do Banco </font><br>
        </td>
      </tr>
      <tr>
        <td align="CENTER"><b><font face="%HTMLFONT%" SIZE="1">%USOBC%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="41"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Carteira </font><br>
        </td>
      </tr>
      <tr>
        <td align="CENTER"><b><font face="%HTMLFONT%" SIZE="1">%CART%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="80"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Esp�cie Moeda </font><br>
        </td>
      </tr>
      <tr align="CENTER">
        <td><b><font face="%HTMLFONT%" SIZE="1">%ESPMOED%&nbsp; </font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="120" colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">Quantidade </font><br>
        </td>
      </tr>
      <tr>
        <td align="CENTER"><b><font face="%HTMLFONT%" SIZE="1">%QTDE%</font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="120"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font face="%HTMLFONT%" SIZE="1">(x) Valor </font><br>
        </td>
      </tr>
      <tr>
        <td><b><font face="%HTMLFONT%" SIZE="1">&nbsp; </font></b><br>
        </td>
      </tr>
    </table>
    </td>
    <td width="150"><table border="0" height="100%" width="100%" cellpadding="0"
    cellspacing="0">
      <tr>
        <td height="50%"><font face="%HTMLFONT%" SIZE="1">(=) Valor do Documento </font><br>
        </td>
      </tr>
      <tr>
        <td align="RIGHT" height="50%"><b><font face="%HTMLFONT%" SIZE="3">%VDOC%
        </font></b><br>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td colspan="6" valign="TOP"><table width="100%" border="0" cellspacing="0"
    cellpadding="0">
      <tr valign="MIDDLE">
        <td height="23"><font face="%HTMLFONT%" SIZE="1"><b>Instru��es (Texto de responsabilidade do
        cedente) </b><br>
        </font></td>
      </tr>
      <tr valign="TOP">
        <td><font face="%HTMLFONT%" size="1">%INSTR1%<br>
        %INSTR2%<br>
        %INSTR3%<br>
        %INSTR4%<br>
        %INSTR5%</font></td>
      </tr>
    </table>
    </td>
    <td><table width="100%" border="1" cellspacing="0" cellpadding="0">
      <tr valign="TOP">
        <td height="23"><font face="%HTMLFONT%" SIZE="1">(-) Descontos/Abatimento <br>
        %DESC%</font></td>
      </tr>
      <tr valign="TOP">
        <td height="23"><font face="%HTMLFONT%" SIZE="1">(-) Outras Dedu��es <br>
        %DDC%</font></td>
      </tr>
      <tr valign="TOP">
        <td height="23"><font face="%HTMLFONT%" SIZE="1">(+) Mora/Multa <br> 
        %MULTA%</font></td>
      </tr>
      <tr valign="TOP">
        <td height="23"><font face="%HTMLFONT%" SIZE="1">(+) Outros Acr�scimos <br>
        %ACRES%</font></td>
      </tr>
      <tr valign="TOP">
        <td height="23"><font face="%HTMLFONT%" SIZE="1">(=) Valor Cobrado <br>
        %VCOBR%</font></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td colspan="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td valign="top" width="100">
            <font face="%HTMLFONT%" SIZE="1">Sacado: </font><br>
          </td>
          <td width="100%" valign="top" rowspan="2">
            <font face="%HTMLFONT%" SIZE="1">%SACADO%<br>%CPF%</font>
          </td>
        </tr>
      </table>
    </td>
    <td colspan="2" valign="bottom" align="center">
      <b><font face="%HTMLFONT%" SIZE="2">Ficha de Compensa��o</font></b>
    </td>
  </tr>
</table>
<table width="640" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td align="left" width="500" nowrap>
      <img src="%BOLETO_IMAGE_URL%espaco.gif" valign="bottom" border="0" height="5" width="5"><br> 
      %BAR%
    </td>
    <td valign=top align=center width=300>
      <font face=%HTMLFONT% SIZE=1>
      <center>Autentica��o Mec�nica</center>
      </font>
    </td>
  </tr>
  <tr>
    <td colspan= 2>
      <hr width="640">
      <div align="left"><b><i>Corte na linha acima</i></b></div>
    </td>
  </tr>
</table>
</p>
