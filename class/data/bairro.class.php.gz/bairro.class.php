<?
/*
class bairro extends database {
	
	function bairro() {

	}

	function getListaBairro() {
		$this->query = "
			SELECT
				cod_bairro,
				nome_bairro
			FROM
				bairro 
			ORDER BY 
				nome_bairro
		";
		$this->query();
		return $this->qrdata;
	}
	
}
*/
?>