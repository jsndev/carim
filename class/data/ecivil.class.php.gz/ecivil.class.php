<?
/*
class ecivil extends database {
	
	function ecivil() {

	}

	function getListaECivil() {
		$this->query = "
			SELECT
				cod_estciv,
				desc_estciv
			FROM
				estadocivil 
			ORDER BY 
				desc_estciv
		";
		$this->query();
		return $this->qrdata;
	}
	
}
*/
?>