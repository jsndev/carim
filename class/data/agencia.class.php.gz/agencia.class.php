<?
/*
class agencia extends database {
	
	function agencia() {
	}
	
	function getAgencia($cod_agencia) {
		$this->query = "
			SELECT
				cod_agbb,
				nome_agbb
			FROM
				agenciabb
			WHERE
				cod_agbb = '".mysql_real_escape_string($cod_agencia)."'
		";
		$this->query();
		return $this->qrdata;
	}
}
*/
?>