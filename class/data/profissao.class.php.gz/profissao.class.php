<?
/*
class profissao extends database {
	
	function profissao() {

	}
	
	function getListaProfissoes() {
		$this->query = "
			SELECT
				cod_prof,
				desc_prof
			FROM
				profissao 
			ORDER BY 
				desc_prof
		";
		$this->query();
		return $this->qrdata;
	}
	
}
*/
?>