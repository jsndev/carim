<?
/*
class cnae extends database {
	
	function cnae() {

	}
	
	function getListaAtivEcon() {
		$this->query = "
			SELECT
				cod_cnae,
				desc_cnae
			FROM
				cnae 
			ORDER BY 
				desc_cnae
		";
		$this->query();
		return $this->qrdata;
	}
	
}
*/
?>