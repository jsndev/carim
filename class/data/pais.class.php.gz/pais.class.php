<?
/*
class pais extends database {
	
	function pais() {
		
	}
	
	function getListaPais() {
		$this->query = "
			SELECT
				cod_pais,
				nome_pais
			FROM
				pais
			ORDER BY
				nome_pais
		";
		$this->query();
		return $this->qrdata;
	}

}
*/
?>