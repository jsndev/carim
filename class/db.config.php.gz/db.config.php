<?
/*
define ("dbuser", "db_athos");
define ("dbpass", "teste123");
define ("dbname", "athos");
define ("dbhost", "magneto.i4t");

define ("dbuser", "athos");
define ("dbpass", "teste123");
define ("dbname", "athos");
define ("dbhost", "192.168.8.18");
*/

define("DB_ERR_FKREF", 1451);  // Erro de integridade referencial
define("DB_ERR_UNIQUE", 1062); // Erro de viola��o de chave unique

define ("dbuser", "sistema");
define ("dbpass", "for/17!kc");
define ("dbname", "carim");
define ("dbhost", "localhost");
?>