<div class="alr">
<? /*
	<a href="#imovel">Dados do Im�vel</a> - 
	<a href="#vendedor">Dados do Vendedor</a> - 
	<a href="#advogado">Check List do Advogado</a> - 
*/ ?>
	<a href="#historico"><img src="images/buttons/bt_historico.gif" alt="Ver Hist�rico" class="im" /></a>
</div>