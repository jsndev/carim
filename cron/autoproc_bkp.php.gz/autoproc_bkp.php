<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>AUTOPROC CARIM</title>
</head>

<frameset rows="0,100%" frameborder="no" border="0" framespacing="0">
  <frame src="autorefresh.php" name="autorefresh" scrolling="yes" id="autorefresh" title="autorefresh" />
  <frame src="frameautoproc.php" name="frameautoproc" scrolling="No" noresize="noresize" id="frameautoproc" title="frameautoproc" />
</frameset>
<noframes><body>
</body>
</noframes></html>
